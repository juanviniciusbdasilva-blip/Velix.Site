/* ═══ CAROUSEL ═══ */
let _slide = 0;
const _slides = 3;
function goSlide(n) {
  const prev = document.getElementById('cs-' + _slide);
  if (prev) { prev.classList.remove('active'); prev.classList.add('exit'); setTimeout(() => prev.classList.remove('exit'), 700); }
  _slide = n;
  const next = document.getElementById('cs-' + _slide);
  if (next) next.classList.add('active');
  document.querySelectorAll('.cdot').forEach((d, i) => d.classList.toggle('active', i === _slide));
}
setInterval(() => goSlide((_slide + 1) % _slides), 4000);

/* ═══ STATE ═══ */
let S = {
  operacoes: {},
  usuarios:  [],
  vinculos:  {},
  cargos:    [],
  selColor:  '#2C4EE8'
};
let SES = null;
let curPage = 'dashboard';
let curCfgTab = 'ops';
let evalOpId = null, evalOpOperacaoId = null, evalChecklistIdx = 0;
let editUsrIdx = null, editOperKey = null, editCargoIdx = null;
let _excelData = null;

const el = id => document.getElementById(id);
const RC = {adm:'#7C3AED',supervisor:'#2C4EE8',monitor:'#2563EB',operador:'#16A34A'};
const RL = {adm:'ADM',supervisor:'Supervisão',monitor:'Monitor',operador:'Operador'};
const COLORS = ['#2C4EE8','#65A30D','#2563EB','#DC2626','#7C3AED','#D97706','#16A34A','#EA580C','#EC4899','#0891B2'];

const ALL_PERMS = [
  {id:'dashboard',    label:'Dashboard'},
  {id:'doEval',       label:'Realizar Avaliações'},
  {id:'viewMyDash',   label:'Ver Próprio Dashboard'},
  {id:'manageUsers',  label:'Gerenciar Usuários'},
  {id:'manageConfig', label:'Configurações'},
  {id:'manageVinc',   label:'Gerenciar Vínculos'},
  {id:'export',       label:'Exportar Dados'},
  {id:'editPerfil',   label:'Editar Perfil & Senha'},
];

const DEF_CHECKLIST = {
  id:'cl-default', nome:'Checklist Padrão',
  blocos:[
    {id:'b1',nome:'Abertura',peso:15,items:[
      {id:'i1',nome:'Apresentação (nome pessoal)',peso:5,allowNA:false},
      {id:'i2',nome:'Identificação da empresa',peso:5,allowNA:false},
      {id:'i3',nome:'Identificação do titular',peso:5,allowNA:false}
    ]},
    {id:'b2',nome:'Negociação',peso:49,items:[
      {id:'i4',nome:'Sondagem',peso:13,allowNA:false},
      {id:'i5',nome:'Quebra de objeção',peso:13,allowNA:false},
      {id:'i6',nome:'Benefício da contratação',peso:13,allowNA:false},
      {id:'i7',nome:'Mencionar valores de crédito',peso:10,allowNA:false}
    ]},
    {id:'b3',nome:'Confirmação',peso:21,items:[
      {id:'i8',nome:'Ratificação da forma de contratar',peso:15,allowNA:false},
      {id:'i9',nome:'Orientar (termos e condições)',peso:6,allowNA:true}
    ]},
    {id:'b4',nome:'Qualidade / Fechamento',peso:15,items:[
      {id:'i10',nome:'Vocabulário adequado',peso:5,allowNA:false},
      {id:'i11',nome:'Agilidade e proatividade',peso:5,allowNA:false},
      {id:'i12',nome:'Atualizar telefone de contato',peso:5,allowNA:true}
    ]}
  ],
  ncg:[
    {id:'n1',label:'NCG Leve',penalidade:-25,tipo:'leve',items:[{id:'n1i1',nome:'Falta de postura / ironia / expressões não cabíveis'}]},
    {id:'n2',label:'NCG Média',penalidade:-26.5,tipo:'media',items:[
      {id:'n2i1',nome:'Compromisso sem certeza da contratação'},
      {id:'n2i2',nome:'Induzir cliente a órgãos reguladores'}
    ]},
    {id:'n3',label:'NCG Grave (ZERAGEM)',penalidade:-100,tipo:'grave',items:[
      {id:'n3i1',nome:'Insultar o usuário'},
      {id:'n3i2',nome:'Derrubar contato sem cumprir Negociação'},
      {id:'n3i3',nome:'Quebra de sigilo para terceiros'},
      {id:'n3i4',nome:'Difamação da empresa ou colegas'}
    ]}
  ]
};

const DEF_OPERS = [
  {id:'FESEIC',nome:'Eric Ferreira da Silva',produto:'PL'},
  {id:'PAULAANN',nome:'Anna Paula Pereira da Silva',produto:'PL'},
  {id:'ROSICONC',nome:'Rosilani da Conceição A. Sozio',produto:'DE'},
  {id:'SOPEDMAR',nome:'Maria Solange Pedro Silva',produto:'PL'},
  {id:'RAFBARBO',nome:'Rafael Barbosa Miranda',produto:'PL'},
  {id:'REALBA',nome:'Renata da Silva Alba de Souza',produto:'PL'},
  {id:'LUCAOLII',nome:'Lucas Oliveira da Silva',produto:'PL'},
  {id:'ITALSOUS',nome:'Ítalo de Sousa Rodrigues',produto:'PL'},
  {id:'ROTANAKA',nome:'Rocco Bruzzese Tanaka',produto:'PL'},
  {id:'SADIEGUE',nome:'Sarah Diegues Mendonça',produto:'PL'}
];

function init() {
  const saved = localStorage.getItem('velix-v1');
  if (saved) { try { Object.assign(S, JSON.parse(saved)); } catch(e){} }
  if (!S.cargos) S.cargos = [];
  if (!Object.keys(S.operacoes).length) {
    const opId = 'op-1';
    S.operacoes[opId] = {
      id:opId, nome:'Mercado Crédito', cor:'#2C4EE8', periodo:'Abril 2026',
      operadores: DEF_OPERS.map(o=>({...o,senha:'1234'})),
      checklists: [JSON.parse(JSON.stringify(DEF_CHECKLIST))],
      avaliacoes: {}
    };
    S.vinculos[opId] = {monitores:[],supervisores:[]};
  }
  if (!S.usuarios.length) {
    const opId = Object.keys(S.operacoes)[0];
    S.usuarios = [
      {id:'u-adm',  matricula:'137954', senha:'1234', nome:'Administrador Master',  roles:['adm'],       opId, criadoPor:'sistema', foto:''},
      {id:'u-adm2', matricula:'123456', senha:'1234', nome:'Admin Principal',       roles:['adm'],       opId, criadoPor:'sistema', foto:''},
      {id:'u-sup',  matricula:'SUP01',  senha:'1234', nome:'Supervisor Geral',       roles:['supervisor'],opId, criadoPor:'137954', foto:''},
      {id:'u-mon',  matricula:'MON01',  senha:'1234', nome:'Monitor Qualidade',      roles:['monitor'],   opId, criadoPor:'137954', foto:''},
      {id:'u-mon2', matricula:'MON02',  senha:'1234', nome:'Monitor + Supervisão',   roles:['monitor','supervisor'], opId, criadoPor:'137954', foto:''},
      ...DEF_OPERS.map(o=>({id:'u-'+o.id, matricula:o.id, senha:'1234', nome:o.nome, roles:['operador'], opId, criadoPor:'137954', foto:''}))
    ];
  }
  Object.keys(S.operacoes).forEach(id=>{
    if (!S.vinculos[id]) S.vinculos[id]={monitores:[],supervisores:[]};
  });
  el('login-screen').style.display='flex';
}

function save() { localStorage.setItem('velix-v1', JSON.stringify(S)); }

/* ═══ AUTH ═══ */
function doLogin() {
  const mat = el('l-mat').value.trim().toUpperCase();
  const pw  = el('l-pw').value.trim();
  const user = S.usuarios.find(u => u.matricula.toUpperCase()===mat && u.senha===pw);
  if (!user) { el('l-err').style.display='block'; return; }
  el('l-err').style.display='none';
  SES = {...user};
  el('login-screen').style.display='none';
  el('app').classList.add('on');
  applyRoleUI();
  populateFilters();
  populateSearchFilters();
  goPage('dashboard');
}

function doLogout() {
  SES=null;
  el('login-screen').style.display='flex';
  el('app').classList.remove('on');
  el('l-mat').value=''; el('l-pw').value='';
}

function hasRole(r) { return SES && SES.roles.includes(r); }
function isAdm()    { return hasRole('adm'); }
function isSup()    { return hasRole('supervisor'); }
function isMon()    { return hasRole('monitor'); }
function isOper()   { return hasRole('operador') && !isAdm() && !isSup() && !isMon(); }

function getUserPerms() {
  if (!SES) return [];
  const base = {
    adm:       ['dashboard','doEval','manageUsers','manageConfig','manageVinc','export','editPerfil'],
    supervisor:['dashboard','doEval','export','editPerfil'],
    monitor:   ['dashboard','doEval','editPerfil'],
    operador:  ['viewMyDash']
  };
  let perms = new Set();
  (SES.roles||[]).forEach(r => {
    (base[r]||[]).forEach(p=>perms.add(p));
    const cargo = S.cargos.find(c=>c.id===r);
    if (cargo) (cargo.permissoes||[]).forEach(p=>perms.add(p));
  });
  return [...perms];
}

function can(action) { return getUserPerms().includes(action); }

function getRoleLabel(r) {
  if (RL[r]) return RL[r];
  const cargo = S.cargos.find(c=>c.id===r);
  return cargo ? cargo.nome : r;
}
function getRoleColor(r) {
  if (RC[r]) return RC[r];
  const cargo = S.cargos.find(c=>c.id===r);
  return cargo ? cargo.cor : '#5A6480';
}
function rolePillHtml(r) {
  const label = getRoleLabel(r);
  const color = getRoleColor(r);
  const isBase = !!RL[r];
  return `<span class="role-pill ${isBase?'rp-'+r:'rp-custom'}" style="${!isBase?'background:'+color+'18;color:'+color+';border-color:'+color+'35':''}">${label}</span>`;
}

function applyRoleUI() {
  updateSidebarAvatar();
  el('sb-user-name').textContent = SES.nome.split(' ').slice(0,2).join(' ');
  el('sb-user-roles').textContent = (SES.roles||[]).map(r=>getRoleLabel(r)).join(', ');
  const show = (id,v) => { const e=el(id); if(e) e.style.display=v?'':'none'; };
  show('nb-avaliacao',   can('doEval'));
  show('nb-meu-perfil',  true);
  show('nb-admin-group', isAdm());
  show('nb-usuarios',    isAdm());
  show('nb-vinculos',    isAdm());
  show('nb-config',      isAdm());
  show('global-search-box', !isOper());
}

function updateSidebarAvatar() {
  if (!SES) return;
  const wrap = el('sb-avatar-wrap');
  const initials_ = SES.nome.split(' ').filter((_,i,a)=>i===0||i===a.length-1).map(w=>w[0]).join('').toUpperCase();
  const primaryRole = SES.roles[0]||'operador';
  if (SES.foto) {
    wrap.innerHTML = `<img src="${SES.foto}" alt="${initials_}" style="width:100%;height:100%;object-fit:cover">`;
    wrap.style.background='transparent';
  } else {
    el('sb-avatar-txt').textContent = initials_;
    const c = getRoleColor(primaryRole);
    wrap.style.background = `linear-gradient(135deg,${c},${c}90)`;
  }
}

/* ═══ NAVIGATION ═══ */
function goPage(page) {
  curPage = page;
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
  const pg = el('page-'+page);
  if (pg) pg.classList.add('active');
  document.querySelectorAll('.nav-btn').forEach(b=>b.classList.remove('active'));
  const nb = el('nb-'+page);
  if (nb) nb.classList.add('active');
  const titles = {dashboard:'Dashboard',avaliacao:'Avaliação','meu-perfil':'Meu Perfil',usuarios:'Usuários',vinculos:'Vínculos',config:'Configurações'};
  el('topbar-title').textContent = titles[page]||page;
  el('topbar-actions').innerHTML='';
  if (page==='dashboard')   renderDash();
  if (page==='avaliacao')   renderEvalSearch();
  if (page==='meu-perfil')  renderMeuPerfil();
  if (page==='usuarios')    renderUsers();
  if (page==='vinculos')    renderVinculos();
  if (page==='config')      renderConfig();
}

/* ═══ HELPERS ═══ */
function getOp(id) { return S.operacoes[id]; }
function allOps()  { return Object.values(S.operacoes); }

function visibleOps() {
  if (isAdm()) return allOps();
  if (isSup()) return allOps().filter(op=>(S.vinculos[op.id]?.supervisores||[]).includes(SES.matricula));
  if (isMon()) return allOps().filter(op=>(S.vinculos[op.id]?.monitores||[]).includes(SES.matricula));
  return [];
}

function visibleOpers() {
  const result = [];
  visibleOps().forEach(op=>{
    (op.operadores||[]).forEach(oper=>{ result.push({...oper,opId:op.id,opNome:op.nome,opCor:op.cor}); });
  });
  return result;
}

function calcScore(operId, opId, clIdx) {
  const op = getOp(opId);
  if (!op) return {total:0,answered:0,blocos:{},hasNCG:false,isZero:false};
  const cl = (op.checklists||[])[clIdx||0];
  if (!cl) return {total:0,answered:0,blocos:{},hasNCG:false,isZero:false};
  const aval = (op.avaliacoes||{})[operId] || {};
  const avalCl = aval[cl.id] || {};
  let total=0,answered=0,blocos={};
  (cl.blocos||[]).forEach(b=>{
    blocos[b.id]=0;
    (b.items||[]).forEach(item=>{
      const v=avalCl[item.id];
      if (v!==undefined&&v!=='na') { answered++; if(v==='sim'){total+=item.peso;blocos[b.id]+=item.peso;} }
    });
  });
  let penalty=0,isZero=false,hasNCG=false;
  (cl.ncg||[]).forEach(n=>{
    (n.items||[]).forEach(ni=>{
      if (avalCl[ni.id]==='sim') { hasNCG=true; if(n.penalidade<=-100)isZero=true; else penalty+=Math.abs(n.penalidade); }
    });
  });
  return {total:isZero?0:Math.max(0,total-penalty),answered,blocos,hasNCG,isZero};
}

function scoreColor(v) {
  if (v<0) return 'var(--text2)';
  if (v>=80) return 'var(--green)';
  if (v>=60) return 'var(--amber)';
  return 'var(--red)';
}
function scoreClass(v,answered) {
  if (!answered) return 'chip-gray';
  if (v>=80) return 'chip-green';
  if (v>=60) return 'chip-amber';
  return 'chip-red';
}
function situacao(v,answered) {
  if (!answered) return 'Pendente';
  if (v>=80) return 'Aprovado';
  if (v>=60) return 'Atenção';
  return 'Crítico';
}
function initials(nome) {
  return nome.split(' ').filter((_,i,a)=>i===0||i===a.length-1).map(w=>w[0]).join('').toUpperCase();
}
function avatarHtml(nome, cor, foto, size=36) {
  const i = initials(nome);
  const r = size>50?18:10;
  const style = `width:${size}px;height:${size}px;border-radius:${r}px;flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:${size>50?24:13}px;font-weight:800;color:#fff;overflow:hidden;`;
  if (foto) return `<div style="${style}background:var(--bg3)"><img src="${foto}" style="width:100%;height:100%;object-fit:cover"></div>`;
  return `<div style="${style}background:linear-gradient(135deg,${cor||'#2C4EE8'},${cor||'#2C4EE8'}90)">${i}</div>`;
}
function todayStr() { return new Date().toISOString().slice(0,10); }
function nowPeriod() { const d=new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`; }

/* ═══ GLOBAL SEARCH ═══ */
function gsSearch(q) {
  const drop = el('gs-dropdown');
  if (!q.trim()) { drop.innerHTML=''; drop.classList.remove('visible'); return; }
  const term = q.trim().toLowerCase();
  const opers = visibleOpers().filter(o=>
    o.nome.toLowerCase().includes(term) || o.id.toLowerCase().includes(term) || o.opNome.toLowerCase().includes(term)
  ).slice(0,8);
  if (!opers.length) { drop.innerHTML='<div class="sd-empty">Nenhum operador encontrado</div>'; drop.classList.add('visible'); return; }
  drop.innerHTML = opers.map(o=>{
    const sc = calcScore(o.id,o.opId,0);
    const nota = sc.answered>0?sc.total.toFixed(1)+'%':'Pendente';
    const cls = scoreClass(sc.total,sc.answered);
    const usr = S.usuarios.find(u=>u.matricula===o.id);
    return `<div class="sd-item" onclick="gsSelect('${o.id}','${o.opId}')">
      ${avatarHtml(o.nome,o.opCor,usr?.foto||'')}
      <div class="sd-item-info"><strong>${highlight(o.nome,term)}</strong><span>${o.id} · ${o.opNome}</span></div>
      <span class="chip ${cls}" style="font-size:9px">${nota}</span>
    </div>`;
  }).join('');
  drop.classList.add('visible');
}

function highlight(text, term) {
  const idx = text.toLowerCase().indexOf(term);
  if (idx<0) return text;
  return text.slice(0,idx)+'<mark>'+text.slice(idx,idx+term.length)+'</mark>'+text.slice(idx+term.length);
}

function gsSelect(operId, opId) {
  el('gs-input').value='';
  el('gs-dropdown').classList.remove('visible');
  if (can('doEval')) openEvalFromDash(operId, opId);
}
function showGsDropdown() { if (el('gs-input').value.trim()) el('gs-dropdown').classList.add('visible'); }
function hideGsDropdown() { el('gs-dropdown').classList.remove('visible'); }

/* ═══ FILTERS ═══ */
function populateFilters() {
  const fOp=el('f-operacao'); const fSup=el('f-supervisor'); const fMon=el('f-monitor');
  if (!fOp) return;
  fOp.innerHTML='<option value="">Todas as operações</option>';
  visibleOps().forEach(op=>{ fOp.innerHTML+=`<option value="${op.id}">${op.nome}</option>`; });
  fSup.innerHTML='<option value="">Todos supervisores</option>';
  fMon.innerHTML='<option value="">Todos monitores</option>';
  S.usuarios.filter(u=>u.roles.includes('supervisor')).forEach(u=>{ fSup.innerHTML+=`<option value="${u.matricula}">${u.nome.split(' ')[0]}</option>`; });
  S.usuarios.filter(u=>u.roles.includes('monitor')).forEach(u=>{ fMon.innerHTML+=`<option value="${u.matricula}">${u.nome.split(' ')[0]}</option>`; });
  if (!el('f-periodo').value) el('f-periodo').value=nowPeriod();
  el('btn-exp-base').style.display=can('export')?'':'none';
  el('btn-exp-dash').style.display=can('export')?'':'none';
  el('btn-dash-eval').style.display=can('doEval')?'':'none';
  el('dash-filters').style.display=isOper()?'none':'';
}

function clearFilters() {
  el('f-operacao').value=''; el('f-supervisor').value=''; el('f-monitor').value='';
  el('f-periodo').value=nowPeriod(); renderDash();
}

function getFilteredRows() {
  const fOp=el('f-operacao')?.value||'';
  let ops=visibleOps();
  if (fOp) ops=ops.filter(o=>o.id===fOp);
  const rows=[];
  ops.forEach(op=>{
    (op.operadores||[]).forEach(oper=>{
      const sc0=calcScore(oper.id,op.id,0);
      const aval=(op.avaliacoes||{})[oper.id]||{};
      const cl0=(op.checklists||[])[0];
      const obs=cl0?(aval[cl0.id]?._obs||''):'';
      rows.push({oper,op,sc:sc0,obs});
    });
  });
  return rows;
}

/* ═══ DASHBOARD ═══ */
function renderDash() {
  if (!SES) return;
  if (isOper()) { renderOperDash(); return; }
  const rows=getFilteredRows();
  const avaliados=rows.filter(r=>r.sc.answered>0);
  const media=avaliados.length?avaliados.reduce((s,r)=>s+r.sc.total,0)/avaliados.length:0;
  const ncg=avaliados.filter(r=>r.sc.hasNCG).length;
  const comJust=avaliados.filter(r=>r.obs.trim()).length;
  const scol=v=>v>=80?'c-green':v>=60?'c-amber':'c-red';
  el('dash-stats').innerHTML=`
    <div class="stat-card"><div class="stat-lbl">Total Operadores</div><div class="stat-val c-cyan">${rows.length}</div><div class="stat-sub">${avaliados.length} avaliados · ${rows.length-avaliados.length} pendentes</div></div>
    <div class="stat-card"><div class="stat-lbl">Média Geral</div><div class="stat-val ${avaliados.length?scol(media):'c-gray'}">${avaliados.length?media.toFixed(1)+'%':'—'}</div><div class="stat-sub">${avaliados.length} avaliações</div></div>
    <div class="stat-card"><div class="stat-lbl">Avaliações</div><div class="stat-val c-blue">${avaliados.length}</div><div class="stat-sub">de ${rows.length} operadores</div></div>
    <div class="stat-card"><div class="stat-lbl">Notas Zeradas</div><div class="stat-val ${ncg>0?'c-red':'c-green'}">${ncg}</div><div class="stat-sub">NCG grave detectada</div></div>
    <div class="stat-card"><div class="stat-lbl">Com Justificativa</div><div class="stat-val ${comJust===avaliados.length&&avaliados.length>0?'c-green':'c-amber'}">${comJust}</div><div class="stat-sub">de ${avaliados.length} avaliações</div></div>
  `;
  const ranges=[{l:0,h:59,c:'var(--red)'},{l:60,h:69,c:'var(--orange)'},{l:70,h:79,c:'var(--amber)'},{l:80,h:89,c:'var(--blue)'},{l:90,h:100,c:'var(--green)'}];
  const dc=ranges.map(r=>avaliados.filter(x=>x.sc.total>=r.l&&x.sc.total<=r.h).length);
  const mx=Math.max(...dc,1);
  el('dist-chart').innerHTML=ranges.map((r,i)=>`<div class="dc"><div class="db" style="height:${Math.round((dc[i]/mx)*80)}px;background:${r.c}"></div><div class="dl">${r.l}-${r.h}</div><div class="dl" style="color:var(--text2)">${dc[i]}</div></div>`).join('');
  const ops=visibleOps(); const firstOp=ops[0];
  let bcHtml='';
  if (firstOp&&firstOp.checklists?.length) {
    const cl=firstOp.checklists[0];
    bcHtml=(cl.blocos||[]).map(b=>{
      const vals=avaliados.filter(r=>r.op.id===firstOp.id).map(r=>(r.sc.blocos[b.id]||0));
      const avg=vals.length?vals.reduce((a,v)=>a+v,0)/vals.length:0;
      const pct=b.peso>0?(avg/b.peso)*100:0;
      const c=pct>=70?'var(--green)':pct>=40?'var(--amber)':'var(--red)';
      return `<div class="bar-row"><div class="bl" title="${b.nome}">${b.nome.slice(0,14)}</div><div class="bo"><div class="bi" style="width:${Math.min(100,pct)}%;background:${c}"></div></div><div class="bv">${avg.toFixed(0)}%</div></div>`;
    }).join('');
  }
  el('bloco-chart').innerHTML=bcHtml||'<div style="font-size:12px;color:var(--text3);padding:8px">Sem dados</div>';
  el('dash-charts-row').style.display='';
  const tbody=el('dash-tbody');
  tbody.innerHTML='';
  rows.forEach((r,i)=>{
    const nota=r.sc.answered>0?r.sc.total.toFixed(1)+'%':'—';
    const cls=scoreClass(r.sc.total,r.sc.answered);
    const sit=situacao(r.sc.total,r.sc.answered);
    const ncgFlag=r.sc.hasNCG?'<span class="chip chip-red">NCG</span>':'';
    const hasObs=r.obs.trim();
    const trAttrs=can('doEval')?'onclick="openEvalFromDash(\''+r.oper.id+'\',\''+r.op.id+'\')" style="cursor:pointer"':'';
    tbody.innerHTML+=`<tr ${trAttrs}>
      <td class="td-mono">${String(i+1).padStart(2,'0')}</td>
      <td><div style="font-size:13px;font-weight:600">${r.oper.nome}</div><div class="td-mono">${r.oper.id}</div></td>
      <td><span class="chip chip-cyan">${r.op.nome}</span></td>
      <td><span class="chip ${cls} td-num">${nota}</span></td>
      <td>${ncgFlag}</td>
      <td><span style="font-size:11px;color:${hasObs?'var(--green)':'var(--text3)'};">${hasObs?'✓ Sim':'—'}</span></td>
      <td><span class="chip ${cls}">${sit}</span></td>
    </tr>`;
  });
}

function renderOperDash() {
  el('dash-charts-row').style.display='none';
  el('btn-exp-base').style.display='none';
  el('btn-exp-dash').style.display='none';
  let oper=null,opFound=null;
  allOps().forEach(op=>{ const o=(op.operadores||[]).find(x=>x.id===SES.matricula); if(o){oper=o;opFound=op;} });
  if (!oper||!opFound) {
    el('dash-stats').innerHTML='<div class="empty"><div class="empty-icon">◎</div><p>Você não está vinculado a nenhuma operação.</p></div>';
    return;
  }
  const sc=calcScore(oper.id,opFound.id,0);
  const color=scoreColor(sc.answered>0?sc.total:-1);
  const sit=situacao(sc.total,sc.answered);
  const clss=scoreClass(sc.total,sc.answered);
  el('dash-stats').innerHTML=`
    <div class="stat-card" style="grid-column:span 2">
      <div class="stat-lbl">Sua Média — ${opFound.nome}</div>
      <div class="stat-val" style="color:${color};font-size:42px">${sc.answered>0?sc.total.toFixed(1)+'%':'Aguardando avaliação'}</div>
      <div class="stat-sub"><span class="chip ${clss}">${sit}</span>${sc.isZero?' — ⚠ NCG Grave detectada':''}</div>
    </div>
    <div class="stat-card">
      <div class="stat-lbl">Avaliações Recebidas</div>
      <div class="stat-val c-blue">${sc.answered>0?1:0}</div>
    </div>
    <div class="stat-card">
      <div class="stat-lbl">Status</div>
      <div class="stat-val" style="font-size:18px;margin-top:4px"><span class="chip ${clss}" style="font-size:13px;padding:4px 12px">${sit}</span></div>
    </div>
  `;
  const tbody=el('dash-tbody');
  tbody.innerHTML='';
  (opFound.checklists||[]).forEach((cl,idx)=>{
    const sc2=calcScore(oper.id,opFound.id,idx);
    if (!sc2.answered) return;
    const color2=scoreColor(sc2.total);
    tbody.innerHTML+=`<tr>
      <td>${avatarHtml(opFound.nome,opFound.cor,'',28)}</td>
      <td><div style="font-size:13px;font-weight:600">${cl.nome}</div><div class="td-mono">${opFound.nome}</div></td>
      <td></td>
      <td class="td-num" style="color:${color2}">${sc2.total.toFixed(1)}%</td>
      <td>${sc2.hasNCG?'<span class="chip chip-red">NCG</span>':''}</td>
      <td><span style="font-size:11px;color:var(--text3)">—</span></td>
      <td><span class="chip ${scoreClass(sc2.total,sc2.answered)}">${situacao(sc2.total,sc2.answered)}</span></td>
    </tr>`;
  });
}

function openEvalFromDash(operId,opId) {
  evalOpId=operId; evalOpOperacaoId=opId; evalChecklistIdx=0;
  goPage('avaliacao');
  el('eval-search').style.display='none';
  el('eval-form').style.display='';
  renderEvalForm();
}

/* ═══ AVALIAÇÃO — BUSCA ═══ */
function populateSearchFilters() {
  const sel=el('s-op'); if(!sel)return;
  sel.innerHTML='<option value="">Todas</option>';
  visibleOps().forEach(op=>{ sel.innerHTML+=`<option value="${op.id}">${op.nome}</option>`; });
}

function renderEvalSearch() {
  el('eval-search').style.display='';
  el('eval-form').style.display='none';
  const nome=(el('s-nome').value||'').trim().toLowerCase();
  const opId=el('s-op').value;
  const all=visibleOpers();
  let filtered=all;
  if(nome) filtered=filtered.filter(o=>o.nome.toLowerCase().includes(nome)||o.id.toLowerCase().includes(nome));
  if(opId) filtered=filtered.filter(o=>o.opId===opId);
  const container=el('eval-results-list');
  if(!nome&&!opId){ container.innerHTML=`<div class="empty"><div class="empty-icon">🔍</div><p>Digite um nome, matrícula ou selecione uma operação para buscar.</p></div>`; return; }
  if(!filtered.length){ container.innerHTML=`<div class="empty"><div class="empty-icon">◎</div><p>Nenhum operador encontrado.</p></div>`; return; }
  container.innerHTML=filtered.map(o=>{
    const sc=calcScore(o.id,o.opId,0);
    const nota=sc.answered>0?sc.total.toFixed(1)+'%':'Pendente';
    const cls=scoreClass(sc.total,sc.answered);
    const usr=S.usuarios.find(u=>u.matricula===o.id);
    return `<div class="eval-r-item" onclick="selectEvalOper('${o.id}','${o.opId}')">
      ${avatarHtml(o.nome,o.opCor,usr?.foto||'')}
      <div class="eval-r-info"><strong>${o.nome}</strong><span>${o.id} · ${o.opNome}</span></div>
      <span class="chip ${cls}">${nota}</span>
    </div>`;
  }).join('');
}

function selectEvalOper(operId,opId) {
  evalOpId=operId; evalOpOperacaoId=opId; evalChecklistIdx=0;
  el('eval-search').style.display='none';
  el('eval-form').style.display='';
  renderEvalForm();
}

function backToEvalSearch() {
  evalOpId=null; evalOpOperacaoId=null;
  el('eval-search').style.display='';
  el('eval-form').style.display='none';
}

/* ═══ AVALIAÇÃO — FORMULÁRIO ═══ */
function renderEvalForm() {
  const op=getOp(evalOpOperacaoId); if(!op)return;
  const oper=(op.operadores||[]).find(o=>o.id===evalOpId); if(!oper)return;
  const cls=op.checklists||[];
  el('eval-bc').textContent=`${op.nome} → ${oper.nome}`;
  const usr=S.usuarios.find(u=>u.matricula===oper.id);
  el('eval-op-avatar').innerHTML='';
  el('eval-op-avatar').style.background=`linear-gradient(135deg,${op.cor||'#2C4EE8'},${op.cor||'#2C4EE8'}90)`;
  if(usr?.foto){ el('eval-op-avatar').innerHTML=`<img src="${usr.foto}" style="width:100%;height:100%;object-fit:cover">`; el('eval-op-avatar').style.background='transparent'; }
  else el('eval-op-avatar').textContent=initials(oper.nome);
  el('eval-op-name').textContent=oper.nome;
  el('eval-op-sub').textContent=`${oper.id} · ${op.nome} · ${oper.produto||'—'}`;
  const tabsEl=el('eval-checklist-tabs');
  tabsEl.innerHTML=cls.map((cl,i)=>`<button class="check-sel-btn ${i===evalChecklistIdx?'active':''}" onclick="switchEvalChecklist(${i})">${cl.nome}</button>`).join('');
  const cl=cls[evalChecklistIdx];
  const aval=(op.avaliacoes||{})[oper.id]||{};
  const avalCl=aval[cl?.id]||{};
  let html='';
  (cl?.blocos||[]).forEach(b=>{
    const bSc=calcScore(oper.id,op.id,evalChecklistIdx).blocos[b.id]||0;
    html+=`<div class="crit-block">
      <div class="crit-block-head" onclick="toggleCB('cb-${b.id}')">
        <h4>${b.nome}</h4><span style="font-size:10px;font-family:var(--mono);color:var(--text3)">${b.peso}%</span>
        <span style="font-size:12px;font-family:var(--mono);font-weight:700;color:${bSc>=b.peso*0.7?'var(--green)':bSc>0?'var(--amber)':'var(--text3)'}">${bSc>0?bSc.toFixed(0)+'%':'—'}</span>
        <span style="font-size:10px;color:var(--text3)" id="ci-cb-${b.id}">▾</span>
      </div>
      <div class="crit-block-body" id="cb-${b.id}">`;
    (b.items||[]).forEach(item=>{
      const v=avalCl[item.id]||null;
      html+=`<div class="criterio"><div class="criterio-name">${item.nome}</div><span class="criterio-w">${item.peso}%</span>
        <div class="rg">
          <button class="rb ${v==='sim'?'s-sim':''}" onclick="setVal('${oper.id}','${item.id}','sim',this)">SIM</button>
          <button class="rb ${v==='nao'?'s-nao':''}" onclick="setVal('${oper.id}','${item.id}','nao',this)">NÃO</button>
          ${item.allowNA?`<button class="rb ${v==='na'?'s-na':''}" onclick="setVal('${oper.id}','${item.id}','na',this)">N/A</button>`:''}
        </div></div>`;
    });
    html+=`</div></div>`;
  });
  (cl?.ncg||[]).forEach(ncg=>{
    html+=`<div class="ncg-block"><div class="ncg-head ${ncg.tipo}" onclick="toggleCB('ncg-${ncg.id}')">
      <h4>${ncg.label}${ncg.penalidade>-100?` (${ncg.penalidade>0?'+':''}${ncg.penalidade} pts)`:''}</h4>
      <span style="font-size:10px;margin-left:auto" id="ci-cb-ncg-${ncg.id}">▾</span>
    </div><div class="ncg-body" id="ncg-${ncg.id}">`;
    (ncg.items||[]).forEach(ni=>{
      const v=avalCl[ni.id]||null;
      html+=`<div class="criterio"><div class="criterio-name">${ni.nome}</div>
        <div class="rg">
          <button class="rb ${v==='sim'?'s-sim':''}" onclick="setVal('${oper.id}','${ni.id}','sim',this)">Detectado</button>
          <button class="rb ${v==='nao'?'s-nao':''}" onclick="setVal('${oper.id}','${ni.id}','nao',this)">Não detectado</button>
        </div></div>`;
    });
    html+=`</div></div>`;
  });
  el('eval-main').innerHTML=html;
  el('sp-obs').value=avalCl._obs||'';
  validateObs();
  updateScorePanel();
}

function switchEvalChecklist(idx) { evalChecklistIdx=idx; renderEvalForm(); }

function toggleCB(id) {
  const e=el(id); if(!e)return;
  e.classList.toggle('collapsed');
}

function setVal(operId,key,val,btn) {
  const op=getOp(evalOpOperacaoId); if(!op)return;
  if(!op.avaliacoes)op.avaliacoes={};
  if(!op.avaliacoes[operId])op.avaliacoes[operId]={};
  const cl=(op.checklists||[])[evalChecklistIdx]; if(!cl)return;
  if(!op.avaliacoes[operId][cl.id])op.avaliacoes[operId][cl.id]={};
  op.avaliacoes[operId][cl.id][key]=val;
  btn.closest('.rg').querySelectorAll('.rb').forEach(b=>b.className='rb');
  btn.className='rb s-'+val;
  save(); updateScorePanel(); updateBadge();
}

function saveObs() {
  if(!evalOpId||!evalOpOperacaoId)return;
  const op=getOp(evalOpOperacaoId); if(!op)return;
  if(!op.avaliacoes)op.avaliacoes={};
  if(!op.avaliacoes[evalOpId])op.avaliacoes[evalOpId]={};
  const cl=(op.checklists||[])[evalChecklistIdx]; if(!cl)return;
  if(!op.avaliacoes[evalOpId][cl.id])op.avaliacoes[evalOpId][cl.id]={};
  op.avaliacoes[evalOpId][cl.id]._obs=el('sp-obs').value;
  save();
}

function validateObs() {
  const obs=(el('sp-obs').value||'').trim();
  const req=el('obs-req'); const field=el('sp-obs');
  if(!obs){ field.classList.add('textarea-required'); req.classList.add('show'); }
  else { field.classList.remove('textarea-required'); req.classList.remove('show'); }
}

function saveEval() {
  const obs=(el('sp-obs').value||'').trim();
  if(!obs){ el('sp-obs').focus(); validateObs(); return; }
  saveObs(); backToEvalSearch();
}

function clearEval() {
  if(!evalOpId||!evalOpOperacaoId)return;
  const op=getOp(evalOpOperacaoId); if(!op||!op.avaliacoes)return;
  const cl=(op.checklists||[])[evalChecklistIdx];
  if(cl&&op.avaliacoes[evalOpId]) delete op.avaliacoes[evalOpId][cl.id];
  save(); renderEvalForm();
}

function updateScorePanel() {
  if(!evalOpId||!evalOpOperacaoId)return;
  const op=getOp(evalOpOperacaoId); if(!op)return;
  const sc=calcScore(evalOpId,evalOpOperacaoId,evalChecklistIdx);
  const color=scoreColor(sc.answered>0?sc.total:-1);
  el('sp-total').textContent=sc.answered>0?sc.total.toFixed(1)+'%':'—';
  el('sp-total').style.color=color;
  const cl=(op.checklists||[])[evalChecklistIdx];
  el('sp-bars').innerHTML=(cl?.blocos||[]).map(b=>{
    const bs=sc.blocos[b.id]||0;
    const pct=b.peso>0?(bs/b.peso)*100:0;
    return `<div class="sbar-wrap">
      <div class="sbar-row"><span>${b.nome}</span><span>${bs>0?bs.toFixed(0)+'%':'—'}</span></div>
      <div class="sbar"><div class="sbar-fill" style="width:${Math.min(100,pct)}%;background:${pct>=70?'var(--green)':pct>=40?'var(--amber)':'var(--red)'}"></div></div>
    </div>`;
  }).join('');
}

function updateBadge() {
  const badge=el('badge-eval'); if(!badge)return;
  let t=0,a=0;
  visibleOps().forEach(op=>{ (op.operadores||[]).forEach(o=>{ t++; if(calcScore(o.id,op.id,0).answered>0)a++; }); });
  badge.textContent=`${a}/${t}`;
}

/* ═══ MEU PERFIL ═══ */
function renderMeuPerfil() {
  if(!SES)return;
  const content=el('perfil-content');
  const isOperadorOnly=isOper();
  let operData=null,opFound=null;
  if(isOperadorOnly) {
    allOps().forEach(op=>{ const o=(op.operadores||[]).find(x=>x.id===SES.matricula); if(o){operData=o;opFound=op;} });
  }
  const photoHtml=SES.foto?`<img src="${SES.foto}" style="width:100%;height:100%;object-fit:cover">`:`<span>${initials(SES.nome)}</span>`;
  const primaryRole=SES.roles[0]||'operador';
  const c=getRoleColor(primaryRole);
  const bg=`linear-gradient(135deg,${c},${c}90)`;

  let html=`<div class="perfil-layout">
    <div class="perfil-left">
      <div class="perfil-card">
        <div class="pf-avatar-wrap">
          <div class="pf-avatar" style="${SES.foto?'background:var(--bg3)':'background:'+bg}">${photoHtml}</div>
          ${can('editPerfil')?`<div class="pf-avatar-edit" onclick="openEditPerfil()">✎</div>`:''}
        </div>
        <div class="pf-name">${SES.nome}</div>
        <div class="pf-mat">${SES.matricula}</div>
        <div class="pf-roles">${(SES.roles||[]).map(r=>rolePillHtml(r)).join(' ')}</div>
        ${opFound?`<div style="margin-top:10px"><span class="chip chip-cyan">${opFound.nome}</span></div>`:''}
      </div>`;

  if(can('editPerfil')) {
    html+=`<div class="panel"><div class="panel-head"><h3>Conta</h3></div>
      <div class="panel-body"><button class="btn btn-primary" onclick="openEditPerfil()" style="width:100%">✎ Editar Perfil & Senha</button></div>
    </div>`;
  }

  html+=`</div><div>`;

  if(isOperadorOnly&&operData&&opFound) {
    const sc=calcScore(operData.id,opFound.id,0);
    const color_=scoreColor(sc.answered>0?sc.total:-1);
    const sit_=situacao(sc.total,sc.answered);
    const cls_=scoreClass(sc.total,sc.answered);
    html+=`<div class="op-score-hero">
      <div class="label">Sua Nota — ${opFound.nome}</div>
      <div class="op-score-num" style="color:${color_}">${sc.answered>0?sc.total.toFixed(1)+'%':'—'}</div>
      <div style="margin-top:8px"><span class="chip ${cls_}" style="font-size:13px;padding:5px 14px">${sit_}</span></div>
      ${sc.isZero?'<div style="color:var(--red);font-size:12px;font-weight:700;margin-top:8px">⚠ NCG Grave detectada</div>':''}
    </div>`;
    html+=`<div class="panel"><div class="panel-head"><h3>Desempenho por Bloco</h3></div>`;
    const cl_=(opFound.checklists||[])[0];
    if(cl_&&sc.answered>0){
      (cl_.blocos||[]).forEach(b=>{
        const bs=sc.blocos[b.id]||0;
        const pct=b.peso>0?(bs/b.peso)*100:0;
        const c_=pct>=70?'var(--green)':pct>=40?'var(--amber)':'var(--red)';
        html+=`<div style="padding:12px 20px;border-bottom:1px solid var(--border)">
          <div style="display:flex;justify-content:space-between;font-size:12px;font-weight:700;margin-bottom:6px"><span>${b.nome}</span><span style="font-family:var(--mono);color:${c_}">${bs.toFixed(0)}%</span></div>
          <div class="sbar"><div class="sbar-fill" style="width:${Math.min(100,pct)}%;background:${c_}"></div></div>
        </div>`;
      });
    } else { html+=`<div class="empty"><p>Sem avaliações ainda.</p></div>`; }
    html+=`</div>`;
  } else {
    html+=`<div class="panel"><div class="panel-head"><h3>Informações do Usuário</h3></div>
      <div class="panel-body">
        <table><tbody>
          <tr><td style="color:var(--text2);font-size:12px;padding:8px 0">Matrícula</td><td style="font-family:var(--mono);font-weight:600;padding:8px 0 8px 16px">${SES.matricula}</td></tr>
          <tr><td style="color:var(--text2);font-size:12px;padding:8px 0">Cargos</td><td style="padding:8px 0 8px 16px">${(SES.roles||[]).map(r=>rolePillHtml(r)).join(' ')}</td></tr>
        </tbody></table>
      </div>
    </div>`;
  }
  html+=`</div></div>`;
  content.innerHTML=html;
}

function openEditPerfil() {
  el('ep-pw').value=''; el('ep-pw2').value='';
  const preview=el('ep-preview');
  if(SES.foto) preview.innerHTML=`<img src="${SES.foto}" style="width:100%;height:100%;object-fit:cover">`;
  else { preview.textContent=initials(SES.nome); const c=getRoleColor(SES.roles[0]); preview.style.background=`linear-gradient(135deg,${c},${c}90)`; }
  openModal('m-edit-perfil');
}

function onPhotoChange(input) {
  const file=input.files[0]; if(!file)return;
  const r=new FileReader();
  r.onload=e=>{ const preview=el('ep-preview'); preview.innerHTML=`<img src="${e.target.result}" style="width:100%;height:100%;object-fit:cover">`; preview.dataset.newPhoto=e.target.result; };
  r.readAsDataURL(file);
}
function onPhotoFromSidebar(input) { onPhotoChange(input); }

function saveEditPerfil() {
  if(isOper()){ alert('Operadores não podem alterar a senha.'); return; }
  const pw=el('ep-pw').value.trim(); const pw2=el('ep-pw2').value.trim();
  if(pw&&pw!==pw2){ alert('As senhas não conferem.'); return; }
  const user=S.usuarios.find(u=>u.matricula===SES.matricula); if(!user)return;
  if(pw){ user.senha=pw; SES.senha=pw; }
  const preview=el('ep-preview');
  if(preview.dataset.newPhoto){ user.foto=preview.dataset.newPhoto; SES.foto=preview.dataset.newPhoto; }
  save(); updateSidebarAvatar(); closeModal('m-edit-perfil'); renderMeuPerfil();
}

/* ═══ USUÁRIOS ═══ */
function renderUsers() {
  if(!isAdm())return;
  const tbody=el('usr-tbody');
  el('usr-count').textContent=`(${S.usuarios.length})`;
  tbody.innerHTML=S.usuarios.map((u,i)=>`
    <tr>
      <td class="td-mono">${String(i+1).padStart(2,'0')}</td>
      <td><div style="font-weight:600">${u.nome}</div></td>
      <td class="td-mono">${u.matricula}</td>
      <td class="td-mono" style="color:var(--text3)">${u.senha}</td>
      <td>${(u.roles||[]).map(r=>rolePillHtml(r)).join(' ')}</td>
      <td>${u.opId?(S.operacoes[u.opId]?.nome||u.opId):'—'}</td>
      <td class="td-mono" style="color:var(--text3)">${u.criadoPor||'—'}</td>
      <td><div style="display:flex;gap:4px">
        <button class="btn btn-sm" onclick="openEditUser(${i})">Editar</button>
        ${u.matricula!==SES.matricula?`<button class="btn btn-sm btn-danger" onclick="deleteUser(${i})">×</button>`:''}
      </div></td>
    </tr>`).join('');
}

function openAddUser() {
  if(!isAdm()){alert('Apenas ADM pode criar usuários.');return;}
  editUsrIdx=null;
  el('m-user-title').textContent='Novo Usuário';
  el('u-nome').value=''; el('u-mat').value=''; el('u-pw').value='1234';
  populateUserRolePills([]);
  populateUserOpSel('');
  openModal('m-user');
}

function openEditUser(i) {
  if(!isAdm()){alert('Apenas ADM pode editar usuários.');return;}
  editUsrIdx=i;
  const u=S.usuarios[i];
  el('m-user-title').textContent='Editar Usuário';
  el('u-nome').value=u.nome; el('u-mat').value=u.matricula; el('u-pw').value=u.senha||'';
  populateUserRolePills(u.roles||[]);
  populateUserOpSel(u.opId||'');
  openModal('m-user');
}

function getAllRoles() {
  const base=['adm','supervisor','monitor','operador'];
  const custom=S.cargos.map(c=>c.id);
  return [...base,...custom];
}

function populateUserRolePills(selected=[]) {
  const base=['adm','supervisor','monitor','operador'];
  const customs=S.cargos;
  const allR=[...base.map(r=>({id:r,label:getRoleLabel(r),isBase:true})),...customs.map(c=>({id:c.id,label:c.nome,isBase:false}))];
  el('u-roles').innerHTML=allR.map(r=>`
    <label style="display:flex;align-items:center;gap:6px;cursor:pointer;padding:5px 10px;border-radius:20px;border:1.5px solid var(--border2);background:${selected.includes(r.id)?'var(--royalBg)':'transparent'};transition:all 0.14s" id="rp-${r.id}">
      <input type="checkbox" id="ur-${r.id}" ${selected.includes(r.id)?'checked':''} onchange="toggleRolePill('${r.id}')" style="accent-color:var(--royal)">
      ${rolePillHtml(r.id)}
    </label>`).join('');
}

function toggleRolePill(r) {
  const lbl=el('rp-'+r); const cb=el('ur-'+r);
  if(cb&&lbl) lbl.style.background=cb.checked?'var(--royalBg)':'transparent';
}

function getSelectedRoles() {
  return getAllRoles().filter(r=>el('ur-'+r)?.checked);
}

function populateUserOpSel(selected='') {
  const sel=el('u-op'); sel.innerHTML='';
  allOps().forEach(op=>{ sel.innerHTML+=`<option value="${op.id}" ${op.id===selected?'selected':''}>${op.nome}</option>`; });
}

function saveUser() {
  if(!isAdm()){alert('Apenas ADM pode salvar usuários.');return;}
  const nome=el('u-nome').value.trim();
  const mat=el('u-mat').value.trim().toUpperCase();
  const pw=el('u-pw').value.trim();
  const opId=el('u-op').value;
  const roles=getSelectedRoles();
  if(!nome||!mat||!pw){alert('Preencha todos os campos obrigatórios.');return;}
  if(!roles.length){alert('Selecione ao menos um cargo.');return;}
  if(editUsrIdx!==null) {
    S.usuarios[editUsrIdx]={...S.usuarios[editUsrIdx],nome,matricula:mat,senha:pw,opId,roles};
  } else {
    if(S.usuarios.find(u=>u.matricula===mat)){alert('Matrícula já cadastrada.');return;}
    S.usuarios.push({id:'u-'+Date.now(),matricula:mat,senha:pw,nome,roles,opId,criadoPor:SES.matricula,foto:''});
  }
  save(); closeModal('m-user'); renderUsers();
}

function deleteUser(i) {
  if(!isAdm()){alert('Apenas ADM pode excluir usuários.');return;}
  if(!confirm('Remover este usuário?'))return;
  S.usuarios.splice(i,1); save(); renderUsers();
}

function importMassUsers() {
  if(!isAdm())return;
  const lines=el('mass-users-text').value.trim().split('\n').filter(l=>l.trim());
  let added=0, erros=[];
  lines.forEach((line,li)=>{
    const parts=line.split(';').map(p=>p.trim());
    if(parts.length<3){erros.push(`Linha ${li+1}: formato inválido`);return;}
    const [nome,mat,pw,rolesStr='operador',opNome=''] = parts;
    const matUp=mat.toUpperCase();
    if(S.usuarios.find(u=>u.matricula===matUp)){erros.push(`Linha ${li+1}: matrícula ${matUp} já existe`);return;}
    const roles=rolesStr.split(',').map(r=>r.trim()).filter(r=>getAllRoles().includes(r));
    if(!roles.length)roles.push('operador');
    let opId=Object.keys(S.operacoes)[0];
    if(opNome){ const op=Object.values(S.operacoes).find(o=>o.nome.toLowerCase()===opNome.toLowerCase()); if(op)opId=op.id; }
    S.usuarios.push({id:'u-'+Date.now()+li,matricula:matUp,senha:pw,nome,roles,opId,criadoPor:SES.matricula,foto:''});
    added++;
  });
  save(); closeModal('m-mass'); renderUsers();
  alert(`${added} usuário(s) importado(s)${erros.length?'\n\nErros:\n'+erros.join('\n'):''}`);
}

/* ═══ CARGOS ═══ */
function renderCargos() {
  const grid=el('cargos-grid');
  const systemCargos=[
    {id:'adm',    nome:'ADM',       cor:'#7C3AED',perms:['dashboard','doEval','manageUsers','manageConfig','manageVinc','export','editPerfil'],system:true},
    {id:'supervisor',nome:'Supervisão',cor:'#2C4EE8',perms:['dashboard','doEval','export','editPerfil'],system:true},
    {id:'monitor',nome:'Monitor',   cor:'#2563EB',perms:['dashboard','doEval','editPerfil'],system:true},
    {id:'operador',nome:'Operador', cor:'#16A34A',perms:['viewMyDash'],system:true},
  ];
  const all=[...systemCargos,...S.cargos];
  grid.innerHTML=all.map((c,i)=>`
    <div class="cargo-card">
      <div class="cargo-card-head">
        <div class="cargo-dot" style="background:${c.cor}"></div>
        <div class="cargo-name">${c.nome}</div>
        ${c.system?'<span style="font-size:9px;color:var(--text3);font-family:var(--mono)">SISTEMA</span>':''}
        ${!c.system?`<button class="btn btn-sm" onclick="editCargo(${S.cargos.findIndex(x=>x.id===c.id)})">✎</button><button class="btn btn-sm btn-danger" onclick="deleteCargo('${c.id}')">×</button>`:''}
      </div>
      <div class="cargo-perm-list">
        ${(c.perms||c.permissoes||[]).map(p=>{ const pm=ALL_PERMS.find(x=>x.id===p); return `<span class="cargo-perm">${pm?pm.label:p}</span>`; }).join('')}
        ${(c.perms||c.permissoes||[]).length===0?'<span style="font-size:11px;color:var(--text3)">Sem permissões</span>':''}
      </div>
    </div>`).join('');
}

function openAddCargo() {
  if(!isAdm()){alert('Apenas ADM pode criar cargos.');return;}
  editCargoIdx=null;
  el('m-cargo-title').textContent='Novo Cargo';
  el('cargo-nome').value='';
  S.selColor='#D97706';
  const cr=el('cargo-color-row');
  cr.innerHTML=COLORS.map(c=>`<div class="color-swatch ${c===S.selColor?'selected':''}" style="background:${c}" onclick="selColor('${c}',this)"></div>`).join('');
  populatePermToggles([]);
  openModal('m-cargo');
}

function editCargo(i) {
  if(!isAdm())return;
  editCargoIdx=i;
  const c=S.cargos[i];
  el('m-cargo-title').textContent='Editar Cargo';
  el('cargo-nome').value=c.nome;
  S.selColor=c.cor||'#D97706';
  const cr=el('cargo-color-row');
  cr.innerHTML=COLORS.map(col=>`<div class="color-swatch ${col===S.selColor?'selected':''}" style="background:${col}" onclick="selColor('${col}',this)"></div>`).join('');
  populatePermToggles(c.permissoes||[]);
  openModal('m-cargo');
}

function populatePermToggles(selected=[]) {
  el('cargo-perms').innerHTML=ALL_PERMS.map(p=>`
    <label class="perm-item ${selected.includes(p.id)?'checked':''}" id="pi-${p.id}">
      <input type="checkbox" id="pc-${p.id}" ${selected.includes(p.id)?'checked':''} onchange="togglePermItem('${p.id}')" style="accent-color:var(--royal)">
      ${p.label}
    </label>`).join('');
}

function togglePermItem(id) {
  const lbl=el('pi-'+id); const cb=el('pc-'+id);
  if(lbl) lbl.classList.toggle('checked', cb.checked);
}

function saveCargo() {
  if(!isAdm())return;
  const nome=el('cargo-nome').value.trim();
  if(!nome){alert('Nome do cargo é obrigatório.');return;}
  const permissoes=ALL_PERMS.map(p=>p.id).filter(id=>el('pc-'+id)?.checked);
  const cargoId='cargo-'+nome.toLowerCase().replace(/\s+/g,'-').replace(/[^a-z0-9-]/g,'');
  if(editCargoIdx!==null) {
    S.cargos[editCargoIdx]={...S.cargos[editCargoIdx],nome,cor:S.selColor,permissoes};
  } else {
    if(S.cargos.find(c=>c.id===cargoId)){alert('Já existe um cargo com esse nome.');return;}
    S.cargos.push({id:cargoId,nome,cor:S.selColor,permissoes});
  }
  save(); closeModal('m-cargo'); renderCargos();
}

function deleteCargo(id) {
  if(!isAdm())return;
  if(!confirm('Remover este cargo? Usuários com esse cargo perderão esse perfil.'))return;
  S.cargos=S.cargos.filter(c=>c.id!==id);
  S.usuarios.forEach(u=>{ u.roles=(u.roles||[]).filter(r=>r!==id); if(!u.roles.length)u.roles=['operador']; });
  save(); renderCargos(); renderUsers();
}

/* ═══ VÍNCULOS ═══ */
function renderVinculos() {
  if(!isAdm())return;
  const ops=allOps();
  if(!ops.length){el('vinc-content').innerHTML='<div class="empty"><p>Nenhuma operação cadastrada.</p></div>';return;}
  el('vinc-content').innerHTML=ops.map(op=>{
    const v=S.vinculos[op.id]||{monitores:[],supervisores:[]};
    const monitors=S.usuarios.filter(u=>(u.roles||[]).includes('monitor'));
    const supers=S.usuarios.filter(u=>(u.roles||[]).includes('supervisor'));
    return `<div class="vinc-card">
      <div class="vinc-head"><div style="width:10px;height:10px;border-radius:50%;background:${op.cor};flex-shrink:0"></div><h4>${op.nome}</h4><span style="font-size:10px;color:var(--text3)">${(op.operadores||[]).length} ops.</span></div>
      <div class="vinc-body">
        <div class="vinc-section-title">Monitores Vinculados</div>
        <div><select style="width:100%;background:var(--bg3);border:1.5px solid var(--border2);border-radius:var(--r);padding:7px 10px;color:var(--text);font-family:var(--font);font-size:12px;outline:none" onchange="addVinc('${op.id}','monitor',this)">
          <option value="">+ Adicionar monitor…</option>
          ${monitors.filter(u=>!(v.monitores||[]).includes(u.matricula)).map(u=>`<option value="${u.matricula}">${u.nome}</option>`).join('')}
        </select></div>
        <div class="vinc-tags">${(v.monitores||[]).map(m=>{const u=S.usuarios.find(x=>x.matricula===m);return u?`<span class="vtag"><span style="color:var(--blue)">●</span>${u.nome.split(' ')[0]}<button onclick="rmVinc('${op.id}','monitor','${m}')">×</button></span>`:''}).join('')}</div>
        <div class="vinc-section-title">Supervisores Vinculados</div>
        <div><select style="width:100%;background:var(--bg3);border:1.5px solid var(--border2);border-radius:var(--r);padding:7px 10px;color:var(--text);font-family:var(--font);font-size:12px;outline:none" onchange="addVinc('${op.id}','supervisor',this)">
          <option value="">+ Adicionar supervisor…</option>
          ${supers.filter(u=>!(v.supervisores||[]).includes(u.matricula)).map(u=>`<option value="${u.matricula}">${u.nome}</option>`).join('')}
        </select></div>
        <div class="vinc-tags">${(v.supervisores||[]).map(s=>{const u=S.usuarios.find(x=>x.matricula===s);return u?`<span class="vtag"><span style="color:var(--royal)">●</span>${u.nome.split(' ')[0]}<button onclick="rmVinc('${op.id}','supervisor','${s}')">×</button></span>`:''}).join('')}</div>
      </div>
    </div>`;
  }).join('');
}

function addVinc(opId,tipo,sel) {
  const val=sel.value; if(!val)return;
  if(!S.vinculos[opId])S.vinculos[opId]={monitores:[],supervisores:[]};
  const arr=tipo==='monitor'?S.vinculos[opId].monitores:S.vinculos[opId].supervisores;
  if(!arr.includes(val))arr.push(val);
  sel.value=''; save(); renderVinculos();
}

function rmVinc(opId,tipo,mat) {
  if(!S.vinculos[opId])return;
  const arr=tipo==='monitor'?S.vinculos[opId].monitores:S.vinculos[opId].supervisores;
  const i=arr.indexOf(mat); if(i>-1)arr.splice(i,1);
  save(); renderVinculos();
}

/* ═══ CONFIGURAÇÕES ═══ */
function renderConfig() {
  populateCfgSelects();
  renderOpsList();
  renderOpersList();
  renderClEditor();
  renderCargos();
}

function switchCfg(tab) {
  curCfgTab=tab;
  ['ops','opers','cl','cargos','dados'].forEach(t=>{
    const e=el('cfg-'+t); if(e) e.style.display=t===tab?'':'none';
    el('cfg-tab-'+t)?.classList.toggle('active',t===tab);
  });
}

function populateCfgSelects() {
  const sel=el('cfg-op-filter'); if(sel){ sel.innerHTML='<option value="">Todas as operações</option>'; allOps().forEach(op=>{sel.innerHTML+=`<option value="${op.id}">${op.nome}</option>`;}); }
  const cl=el('cl-op-sel'); if(cl){ const cur=cl.value; cl.innerHTML=''; allOps().forEach(op=>{cl.innerHTML+=`<option value="${op.id}" ${op.id===cur?'selected':''}>${op.nome}</option>`;}); if(!cl.value&&allOps().length)cl.value=allOps()[0].id; }
  const mp=el('mass-oper-op'); if(mp){ mp.innerHTML=''; allOps().forEach(op=>{mp.innerHTML+=`<option value="${op.id}">${op.nome}</option>`;}); }
  const ic=el('import-cl-op'); if(ic){ ic.innerHTML=''; allOps().forEach(op=>{ic.innerHTML+=`<option value="${op.id}">${op.nome}</option>`;}); }
}

function renderOpsList() {
  const ops=allOps();
  el('ops-list').innerHTML=ops.map(op=>`<div class="list-item">
    <div style="width:12px;height:12px;border-radius:50%;background:${op.cor};flex-shrink:0"></div>
    <div class="li-info"><strong>${op.nome}</strong><span>${op.periodo||'Sem período'} · ${(op.operadores||[]).length} operadores · ${(op.checklists||[]).length} checklist(s)</span></div>
    <div class="li-actions">${ops.length>1?`<button class="btn btn-sm btn-danger" onclick="deleteOp('${op.id}')">Remover</button>`:''}</div>
  </div>`).join('');
}

function renderOpersList() {
  const fId=el('cfg-op-filter')?.value||'';
  let list=[];
  allOps().forEach(op=>{ if(fId&&op.id!==fId)return; (op.operadores||[]).forEach((o,i)=>list.push({...o,opId:op.id,opNome:op.nome,idx:i})); });
  el('oper-count').textContent=`(${list.length})`;
  el('opers-list').innerHTML=list.map(o=>`<div class="list-item">
    <div class="li-info"><strong>${o.nome}</strong><span>${o.id} · ${o.opNome} · ${o.produto||'—'} · Senha: ${o.senha||'—'}</span></div>
    <div class="li-actions">
      <button class="btn btn-sm" onclick="openEditOper('${o.id}','${o.opId}')">Editar</button>
      <button class="btn btn-sm btn-danger" onclick="deleteOper('${o.id}','${o.opId}')">×</button>
    </div>
  </div>`).join('');
}

/* ═══ CHECKLISTS ═══ */
function renderClEditor() {
  const opId=el('cl-op-sel')?.value; if(!opId)return;
  const op=getOp(opId); if(!op)return;
  if(!op.checklists||!op.checklists.length){ op.checklists=[JSON.parse(JSON.stringify(DEF_CHECKLIST))]; save(); }
  const cls=op.checklists;
  const curClIdx=Math.min(window._curClIdx||0,cls.length-1);
  window._curClIdx=curClIdx;
  const cl=cls[curClIdx];
  el('cl-tabs').innerHTML=cls.map((c,i)=>`<button class="cl-tab ${i===curClIdx?'active':''}" onclick="switchClTab(${i})">${c.nome}</button>`).join('');
  el('cl-cur-name').value=cl.nome;
  const edit=el('cl-editor');
  edit.innerHTML=(cl.blocos||[]).map((b,bi)=>{
    const bw=b.items.reduce((s,it)=>s+parseFloat(it.peso||0),0);
    return `<div class="cl-block">
      <div class="cl-block-head">
        <span style="font-size:10px;color:var(--text3);font-family:var(--mono)">#${bi+1}</span>
        <input class="clname" value="${b.nome}" onchange="updateBloco('${opId}',${curClIdx},${bi},'nome',this.value)">
        <span style="font-size:11px;color:var(--text2)">Peso:</span>
        <input class="clw" value="${b.peso}" type="number" min="0" max="100" onchange="updateBloco('${opId}',${curClIdx},${bi},'peso',this.value)">
        <button class="btn btn-sm" onclick="addBlocoItem('${opId}',${curClIdx},${bi})">+ Item</button>
        <button class="btn btn-sm btn-danger" onclick="deleteBloco('${opId}',${curClIdx},${bi})">×</button>
      </div>
      ${(b.items||[]).map((item,ii)=>`<div class="cl-item-row">
        <span style="font-size:10px;color:var(--text3);font-family:var(--mono);min-width:18px">${ii+1}</span>
        <input class="iname" value="${item.nome}" onchange="updateBlocoItem('${opId}',${curClIdx},${bi},${ii},'nome',this.value)">
        <input class="iw" value="${item.peso}" type="number" onchange="updateBlocoItem('${opId}',${curClIdx},${bi},${ii},'peso',this.value)">
        <label class="na-check"><input type="checkbox" ${item.allowNA?'checked':''} onchange="updateBlocoItem('${opId}',${curClIdx},${bi},${ii},'na',this.checked)"> N/A</label>
        <button class="btn btn-sm btn-danger" onclick="deleteBlocoItem('${opId}',${curClIdx},${bi},${ii})" style="padding:2px 6px;font-size:10px">×</button>
      </div>`).join('')}
      <div class="cl-wsum ${Math.abs(bw-b.peso)<0.01?'ok':'warn'}">Soma: ${bw}% ${Math.abs(bw-b.peso)<0.01?'✓':`⚠ (deve ser ${b.peso}%)`}</div>
    </div>`;
  }).join('');
  const total=(cl.blocos||[]).reduce((s,b)=>s+parseFloat(b.peso||0),0);
  edit.innerHTML+=`<div class="cl-wsum ${Math.abs(total-100)<0.01?'ok':'warn'}" style="margin-top:8px">Total: ${total}% ${Math.abs(total-100)<0.01?'✓':'⚠ (deve ser 100%)'}</div>`;
}

function switchClTab(i) { window._curClIdx=i; renderClEditor(); }
function updateClName(v) { const opId=el('cl-op-sel').value; const op=getOp(opId); if(!op)return; op.checklists[window._curClIdx||0].nome=v; save(); renderClEditor(); }

function addChecklistToOp() {
  const opId=el('cl-op-sel').value; const op=getOp(opId); if(!op)return;
  const newCl={...JSON.parse(JSON.stringify(DEF_CHECKLIST)),id:'cl-'+Date.now(),nome:`Checklist ${(op.checklists||[]).length+1}`};
  if(!op.checklists)op.checklists=[];
  op.checklists.push(newCl);
  window._curClIdx=op.checklists.length-1;
  save(); renderClEditor();
}

function removeCurrentChecklist() {
  const opId=el('cl-op-sel').value; const op=getOp(opId); if(!op)return;
  if((op.checklists||[]).length<=1){alert('Deve haver ao menos 1 checklist.');return;}
  if(!confirm('Remover este checklist?'))return;
  op.checklists.splice(window._curClIdx||0,1);
  window._curClIdx=0; save(); renderClEditor();
}

function addBlock() {
  const opId=el('cl-op-sel').value; const op=getOp(opId); if(!op)return;
  const cl=op.checklists[window._curClIdx||0]; if(!cl)return;
  if(!cl.blocos)cl.blocos=[];
  cl.blocos.push({id:'b-'+Date.now(),nome:'Novo Bloco',peso:0,items:[]});
  save(); renderClEditor();
}

function deleteBloco(opId,cli,bi){ const cl=getOp(opId)?.checklists?.[cli]; if(!cl)return; cl.blocos.splice(bi,1); save(); renderClEditor(); }
function addBlocoItem(opId,cli,bi){ const cl=getOp(opId)?.checklists?.[cli]; if(!cl)return; cl.blocos[bi].items.push({id:'i-'+Date.now(),nome:'Novo critério',peso:0,allowNA:false}); save(); renderClEditor(); }
function deleteBlocoItem(opId,cli,bi,ii){ const cl=getOp(opId)?.checklists?.[cli]; if(!cl)return; cl.blocos[bi].items.splice(ii,1); save(); renderClEditor(); }
function updateBloco(opId,cli,bi,key,val){ const cl=getOp(opId)?.checklists?.[cli]; if(!cl)return; if(key==='peso')cl.blocos[bi].peso=parseFloat(val)||0; else cl.blocos[bi][key]=val; save(); if(key==='peso')renderClEditor(); }
function updateBlocoItem(opId,cli,bi,ii,key,val){ const cl=getOp(opId)?.checklists?.[cli]; if(!cl)return; if(key==='peso')cl.blocos[bi].items[ii].peso=parseFloat(val)||0; else if(key==='na')cl.blocos[bi].items[ii].allowNA=val; else cl.blocos[bi].items[ii][key]=val; save(); if(key==='peso')renderClEditor(); }
function saveChecklist(){ save(); alert('Checklist salvo com sucesso!'); }

/* ═══ IMPORTAÇÃO EXCEL ═══ */
function onExcelDrop(e) {
  e.preventDefault();
  el('excel-drop-zone').classList.remove('drag');
  const file=e.dataTransfer.files[0];
  if(file) processExcelFile(file);
}

function onExcelFile(input) {
  const file=input.files[0];
  if(file) processExcelFile(file);
}

function processExcelFile(file) {
  const ext=file.name.split('.').pop().toLowerCase();
  const reader=new FileReader();
  if(ext==='csv') {
    reader.onload=e=>{ parseCSVChecklist(e.target.result); };
    reader.readAsText(file,'UTF-8');
  } else {
    reader.onload=e=>{
      try {
        el('excel-preview').innerHTML=`<div style="background:var(--amberBg);border:1px solid rgba(217,119,6,0.2);border-radius:var(--r);padding:12px;font-size:12px;color:var(--amber)">
          ⚠ Para .xlsx, salve o arquivo como CSV (UTF-8) antes de importar.<br>
          <span style="color:var(--text3)">No Excel: Arquivo → Salvar Como → CSV UTF-8</span>
        </div>`;
        el('btn-import-cl-confirm').style.display='none';
      } catch(err) {
        el('excel-preview').innerHTML=`<div style="color:var(--red);font-size:12px">Erro: ${err.message}</div>`;
      }
    };
    reader.readAsArrayBuffer(file);
  }
}

function parseCSVChecklist(text) {
  const lines=text.split('\n').map(l=>l.trim()).filter(l=>l);
  if(!lines.length){ el('excel-preview').innerHTML='<div style="color:var(--red);font-size:12px">Arquivo vazio.</div>'; return; }
  const sep=lines[0].includes(';')?';':',';
  const headers=lines[0].split(sep).map(h=>h.trim().toLowerCase().replace(/['"]/g,''));
  const iBloco=headers.findIndex(h=>h.includes('bloco')||h.includes('block'));
  const iCrit=headers.findIndex(h=>h.includes('crit')||h.includes('item')||h.includes('nome'));
  const iPeso=headers.findIndex(h=>h.includes('peso')||h.includes('weight'));
  const iNA=headers.findIndex(h=>h.includes('na')||h.includes('n/a'));
  if(iBloco<0||iCrit<0||iPeso<0){
    el('excel-preview').innerHTML=`<div style="color:var(--red);font-size:12px">Colunas não reconhecidas. Use: Bloco, Critério, Peso (e opcionalmente N/A).<br>Cabeçalho: ${headers.join(', ')}</div>`;
    el('btn-import-cl-confirm').style.display='none';
    return;
  }
  const blocos={};
  const blocoOrder=[];
  lines.slice(1).forEach(line=>{
    const cols=line.split(sep).map(c=>c.trim().replace(/^['"]|['"]$/g,''));
    const blocoNome=cols[iBloco]||''; const critNome=cols[iCrit]||''; const peso=parseFloat(cols[iPeso])||0; const allowNA=iNA>=0?['sim','yes','1','true'].includes((cols[iNA]||'').toLowerCase()):false;
    if(!blocoNome||!critNome)return;
    if(!blocos[blocoNome]){ blocos[blocoNome]={nome:blocoNome,peso:0,items:[]}; blocoOrder.push(blocoNome); }
    blocos[blocoNome].items.push({id:'i-'+Date.now()+Math.random(),nome:critNome,peso,allowNA});
  });
  blocoOrder.forEach(bn=>{ blocos[bn].peso=blocos[bn].items.reduce((s,it)=>s+it.peso,0); });
  _excelData={blocoOrder,blocos};
  const total=blocoOrder.reduce((s,bn)=>s+blocos[bn].peso,0);
  el('excel-preview').innerHTML=`
    <div style="font-size:12px;color:var(--green);font-weight:700;margin-bottom:10px">✓ ${blocoOrder.length} blocos · ${blocoOrder.reduce((s,bn)=>s+blocos[bn].items.length,0)} critérios · Total: ${total.toFixed(0)}%</div>
    <div style="max-height:200px;overflow-y:auto;border:1.5px solid var(--border);border-radius:var(--r);overflow:hidden">
    ${blocoOrder.map(bn=>`
      <div style="padding:9px 13px;border-bottom:1px solid var(--border);background:var(--bg3)">
        <strong style="font-size:12px">${blocos[bn].nome}</strong><span style="font-size:10px;color:var(--text3);margin-left:8px">${blocos[bn].peso.toFixed(0)}%</span>
      </div>
      ${blocos[bn].items.map(it=>`<div style="padding:5px 13px 5px 25px;border-bottom:1px solid var(--border);font-size:11px;display:flex;justify-content:space-between"><span>${it.nome}</span><span style="font-family:var(--mono);color:var(--text3)">${it.peso}% ${it.allowNA?'·N/A':''}</span></div>`).join('')}
    `).join('')}
    </div>`;
  el('btn-import-cl-confirm').style.display='';
}

function confirmImportCl() {
  if(!_excelData)return;
  const opId=el('import-cl-op').value; const op=getOp(opId); if(!op)return;
  const {blocoOrder,blocos}=_excelData;
  const newCl={
    id:'cl-'+Date.now(),
    nome:'Checklist Importado',
    blocos:blocoOrder.map(bn=>({id:'b-'+Date.now()+Math.random(),nome:blocos[bn].nome,peso:blocos[bn].peso,items:blocos[bn].items})),
    ncg:[]
  };
  if(!op.checklists)op.checklists=[];
  op.checklists.push(newCl);
  window._curClIdx=op.checklists.length-1;
  _excelData=null;
  el('excel-preview').innerHTML='';
  el('btn-import-cl-confirm').style.display='none';
  save(); closeModal('m-import-cl'); renderClEditor();
  alert('Checklist importado com sucesso!');
}

/* ═══ OPERAÇÕES ═══ */
function openAddOp() {
  S.selColor='#2C4EE8';
  el('op-nome').value=''; el('op-periodo').value='';
  const cr=el('op-color-row');
  cr.innerHTML=COLORS.map(c=>`<div class="color-swatch ${c==='#2C4EE8'?'selected':''}" style="background:${c}" onclick="selColor('${c}',this)"></div>`).join('');
  openModal('m-op');
}

function selColor(c,el2) {
  S.selColor=c;
  document.querySelectorAll('.color-swatch').forEach(e=>e.classList.remove('selected'));
  el2.classList.add('selected');
}

function saveOp() {
  const nome=el('op-nome').value.trim(); if(!nome){alert('Nome obrigatório.');return;}
  const id='op-'+Date.now();
  S.operacoes[id]={id,nome,cor:S.selColor||'#2C4EE8',periodo:el('op-periodo').value.trim(),operadores:[],checklists:[JSON.parse(JSON.stringify(DEF_CHECKLIST))],avaliacoes:{}};
  S.vinculos[id]={monitores:[],supervisores:[]};
  save(); closeModal('m-op'); renderOpsList(); populateCfgSelects(); populateFilters();
}

function deleteOp(id) {
  if(allOps().length<=1){alert('Não é possível remover a única operação.');return;}
  if(!confirm('Remover operação e todos os dados?'))return;
  delete S.operacoes[id]; delete S.vinculos[id];
  save(); renderOpsList(); populateCfgSelects();
}

/* ═══ OPERADORES ═══ */
function openAddOper() {
  editOperKey=null;
  el('m-oper-title').textContent='Adicionar Operador';
  el('oper-nome').value=''; el('oper-mat').value=''; el('oper-pw').value='1234'; el('oper-prod').value='PL';
  const sel=el('oper-op'); sel.innerHTML=''; allOps().forEach(op=>{sel.innerHTML+=`<option value="${op.id}">${op.nome}</option>`;});
  openModal('m-oper');
}

function openEditOper(operId,opId) {
  editOperKey={operId,opId};
  const op=getOp(opId); const oper=(op.operadores||[]).find(o=>o.id===operId); if(!oper)return;
  el('m-oper-title').textContent='Editar Operador';
  el('oper-nome').value=oper.nome; el('oper-mat').value=oper.id; el('oper-pw').value=oper.senha||''; el('oper-prod').value=oper.produto||'PL';
  const sel=el('oper-op'); sel.innerHTML=''; allOps().forEach(o=>{sel.innerHTML+=`<option value="${o.id}" ${o.id===opId?'selected':''}>${o.nome}</option>`;});
  openModal('m-oper');
}

function saveOper() {
  const nome=el('oper-nome').value.trim(); const mat=el('oper-mat').value.trim().toUpperCase(); const pw=el('oper-pw').value.trim();
  const prod=el('oper-prod').value; const opId=el('oper-op').value;
  if(!nome||!mat){alert('Nome e matrícula são obrigatórios.');return;}
  const op=getOp(opId); if(!op)return;
  if(!op.operadores)op.operadores=[];
  if(editOperKey) { const idx=op.operadores.findIndex(o=>o.id===editOperKey.operId); if(idx>-1) op.operadores[idx]={...op.operadores[idx],id:mat,nome,senha:pw,produto:prod}; }
  else { op.operadores.push({id:mat,nome,senha:pw,produto:prod}); }
  save(); closeModal('m-oper'); renderOpersList();
}

function deleteOper(operId,opId) {
  if(!confirm('Remover operador?'))return;
  const op=getOp(opId); const i=op.operadores.findIndex(o=>o.id===operId);
  if(i>-1){ op.operadores.splice(i,1); if(op.avaliacoes) delete op.avaliacoes[operId]; }
  save(); renderOpersList();
}

function importMassOpers() {
  const lines=el('mass-opers-text').value.trim().split('\n').filter(l=>l.trim());
  const defOpId=el('mass-oper-op').value||allOps()[0]?.id;
  let added=0, erros=[];
  lines.forEach((line,li)=>{
    const parts=line.split(';').map(p=>p.trim());
    if(parts.length<2){erros.push(`Linha ${li+1}: formato inválido`);return;}
    const [nome,mat,pw='1234',prod='PL',opNome=''] = parts;
    const matUp=mat.toUpperCase();
    let opId=defOpId;
    if(opNome){ const o=allOps().find(x=>x.nome.toLowerCase()===opNome.toLowerCase()); if(o)opId=o.id; }
    const op=getOp(opId); if(!op){erros.push(`Linha ${li+1}: operação não encontrada`);return;}
    if((op.operadores||[]).find(o=>o.id===matUp)){erros.push(`Linha ${li+1}: ${matUp} já existe`);return;}
    if(!op.operadores)op.operadores=[];
    op.operadores.push({id:matUp,nome,senha:pw,produto:prod});
    added++;
  });
  save(); closeModal('m-mass-oper'); renderOpersList();
  alert(`${added} operador(es) importado(s)${erros.length?'\n\nErros:\n'+erros.join('\n'):''}`);
}

/* ═══ EXPORTAÇÃO ═══ */
function exportBase() {
  if(!can('export'))return;
  const rows=getFilteredRows();
  const lines=['Operador\tMatrícula\tOperação\tProduto\tNota Final\tNCG\tJustificativa\tSituação'];
  rows.forEach(r=>{
    const nota=r.sc.answered>0?r.sc.total.toFixed(2):'';
    const sit=situacao(r.sc.total,r.sc.answered);
    lines.push(`${r.oper.nome}\t${r.oper.id}\t${r.op.nome}\t${r.oper.produto||''}\t${nota}\t${r.sc.hasNCG?'SIM':''}\t${(r.obs||'').replace(/\n/g,' ')}\t${sit}`);
  });
  dl('\uFEFF'+lines.join('\n'),`base-monitoria-${todayStr()}.csv`,'text/csv');
}

function exportDash() {
  if(!can('export'))return;
  const rows=getFilteredRows();
  const av=rows.filter(r=>r.sc.answered>0);
  const media=av.length?(av.reduce((s,r)=>s+r.sc.total,0)/av.length).toFixed(2):0;
  const ncg=av.filter(r=>r.sc.hasNCG).length;
  const cj=av.filter(r=>r.obs.trim()).length;
  const lines=[
    'RELATÓRIO — VELIX — MONITORIA DE QUALIDADE',`Data: ${new Date().toLocaleDateString('pt-BR')}`,'',
    'INDICADORES',
    `Total Operadores\t${rows.length}`,`Avaliados\t${av.length}`,`Média Geral\t${media}%`,
    `NCG Graves\t${ncg}`,`Com Justificativa\t${cj}`,
    `Cobertura\t${rows.length>0?((av.length/rows.length)*100).toFixed(0):0}%`,'',
    'DETALHAMENTO','Operador\tMatrícula\tOperação\tNota\tNCG\tJustificativa\tSituação',
    ...rows.map(r=>{const nota=r.sc.answered>0?r.sc.total.toFixed(2):'—';const sit=situacao(r.sc.total,r.sc.answered);return `${r.oper.nome}\t${r.oper.id}\t${r.op.nome}\t${nota}\t${r.sc.hasNCG?'SIM':''}\t${(r.obs||'').replace(/\n/g,' ')}\t${sit}`;})
  ];
  dl('\uFEFF'+lines.join('\n'),`relatorio-velix-${todayStr()}.csv`,'text/csv');
}

function exportJSON(){ dl(JSON.stringify(S,null,2),`backup-velix-${todayStr()}.json`,'application/json'); }
function importJSON(input){ const f=input.files[0];if(!f)return; const r=new FileReader();r.onload=e=>{try{Object.assign(S,JSON.parse(e.target.result));save();location.reload();}catch{alert('Arquivo inválido.');}};r.readAsText(f); }
function resetAll(){ if(!confirm('Resetar TODOS os dados? Esta ação é irreversível.'))return; localStorage.removeItem('velix-v1');location.reload(); }
function dl(content,name,type){ const b=new Blob([content],{type});const u=URL.createObjectURL(b);const a=document.createElement('a');a.href=u;a.download=name;a.click();URL.revokeObjectURL(u); }

/* ═══ MODALS ═══ */
function openModal(id){ el(id).classList.add('open'); }
function closeModal(id){ el(id).classList.remove('open'); }
document.addEventListener('click',e=>{ if(e.target.classList.contains('modal-backdrop'))e.target.classList.remove('open'); });

/* ═══ START ═══ */
init();
</script>
